import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ProfileSelectionController {

    @FXML
    private Label currentLevel;

    @FXML
    private Label UserName;

    @FXML
    private Label dailyMessage;

    @FXML
    private Button prevProfileButton;

    @FXML
    private Label currentScore;

    @FXML
    private Button nextProfileButton;

    @FXML
    private Button editProfileButton;

    @FXML
    private Button deleteProfileButton;

    @FXML
    private Button playButton;
    
    @FXML
    private Button newProfileButton;
    
    private int currentProfile = 0;
    private Boolean createProfile = false;
    @FXML
	 public void initialize() {
    	if (Game.users.isEmpty() || createProfile) {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("fxmlScenes\\CreateProfile.fxml"));     

			// Run the loader
			AnchorPane editRoot;
			try {
				editRoot = (AnchorPane)fxmlLoader.load();
			      
			// Access the controller that was created by the FXML loader
			CreateProfileController createProfile = fxmlLoader.<CreateProfileController>getController();
			
			// Create a scene based on the loaded FXML scene graph
			Scene editScene = new Scene(editRoot);
		    
			// Create a new stage (i.e., window) based on the edit scene
			Stage editStage = new Stage();
			editStage.setScene(editScene);
			editStage.setTitle("Create Profile");
			
			// Make the stage a modal window.
			// This means that it must be closed before you can interact with any other window from this application.
			editStage.initModality(Modality.APPLICATION_MODAL);
			
			// Show the edit scene and wait for it to be closed
			editStage.showAndWait();
//    		Stage stage = new Stage();
//    		Game.createNewProfile(stage);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    
			createProfile = false;
    	}
    	dailyMessage.setText(Game.loadDailyMessage());
    	UserName.setText(Game.users.get(currentProfile).getUserName());
    	currentScore.setText("CURRENT SCORE: " + Integer.toString(Game.users.get(currentProfile).getCurrentScore()));
    	currentLevel.setText(Game.users.get(currentProfile).getInfo());    	
	}

	
	
	
//	profileButtons.getChildren().addAll(load,deleteUser,newUser,quickLoad);
//	loadFile.setBottom(profileButtons);
//	loadFile.setTop(dailyMessage);
//	dailyMessage.setMinHeight(GRID_CELL_HEIGHT);

	
	 
    @FXML
    void handleDeleteProfileAction(ActionEvent event) {	
		Game.users.remove(currentProfile);
		Game.updateProfiles();
		Game.loadProfiles();
		currentProfile = 0;
		initialize();
    }

    @FXML
    void handleEditProfileAction(ActionEvent event) {

    }

    @FXML
    void handleNewProfileAction(ActionEvent event) {
    	createProfile = true;
    	initialize();
    }

    @FXML
    void handleNextProfileAction(ActionEvent event) {
    	if (currentProfile == Game.users.size() - 1) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error: Cannot load user");
			alert.setHeaderText(null);
			alert.setContentText("No profiles next.");
			alert.showAndWait();
    	} else {
    	currentProfile = currentProfile + 1;
    	initialize();
    	}
    }

    @FXML
    void handlePrevProfileAction(ActionEvent event) {
    	if (currentProfile == 0) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error: Cannot load user");
			alert.setHeaderText(null);
			alert.setContentText("No profiles previous.");
			alert.showAndWait();
    	} else {
    		currentProfile = currentProfile - 1;
    		initialize();
    	}
    	 
    }
    
    @FXML
    void handlePlayAction(ActionEvent event) {
    	Game.currentUser = Game.users.get(currentProfile);
		File file = new File((Game.users.get(currentProfile).getUserName())+"playersave.txt");
		File file2 = new File((Game.users.get(currentProfile).getUserName())+"levelsave.txt");
		Stage stage = new Stage();
		if (file.exists()) {
			Game.level = new Level((Game.users.get(currentProfile).getUserName())+"levelsave.txt");
			Game.player = new Player(Game.level);
			try {
				Scanner input = new Scanner(file);
				input.useDelimiter(",");
				Game.player.setBlueKeys(input.nextInt());
				Game.player.setFireBoots(input.nextBoolean());
				Game.player.setFlippers(input.nextBoolean());
				Game.player.setGreenKeys(input.nextInt());
				Game.player.setRedKeys(input.nextInt());
				Game.player.setTokens(input.nextInt());
				Game.player.setYellowKeys(input.nextInt());
				Game.timeDelay = input.nextInt();
				input.close();
				file.delete();
				file2.delete();
				Game.game(stage);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
	
    	} else {
			Game.userMenu(stage);
		}
    }
}