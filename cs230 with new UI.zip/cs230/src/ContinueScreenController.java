import java.io.File;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ContinueScreenController {

    @FXML
    private Button continueButton;

    @FXML
    private Button selectLevelButton;

    @FXML
    private Button backButton;
    
    @FXML
    private AnchorPane AnchorPane;

    @FXML
	 public void initialize() {
    	File file = new File((Game.users.get(Game.chosenProfile).getUserName())+"playersave.txt");
		File file2 = new File((Game.users.get(Game.chosenProfile).getUserName())+"levelsave.txt");
		if (!file.exists()) {
			continueButton.setOpacity(0.5);
			continueButton.setDisable(true);
	    } else {
	    	continueButton.setOpacity(1);
	    	continueButton.setDisable(false);
	    }
	}
    
    @FXML
    void handleBackAction(ActionEvent event) {
    	Stage stage = (Stage) backButton.getScene().getWindow();
    	Game.mainmenu(stage);
    }

    @FXML
    void handleContinueAction(ActionEvent event) {   	
    	Stage stage = (Stage) continueButton.getScene().getWindow();
    	stage.close();
    	Game.loadSave(Game.chosenProfile, stage);
    }

    @FXML
    void handleSelectLevelAction(ActionEvent event) {
    	Stage stage = (Stage) selectLevelButton.getScene().getWindow();
    	stage.close();
    	Game.selectLevel(stage);
	}
    
}
