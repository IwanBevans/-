// The abstract class of doors checks if the door is locked or not
/**
 * The abstract class for the Door object.
 * @author Elliot Davis
 * @version 1.0
 */
public abstract class Door extends Tile{
	private boolean isLocked;

	/**
	 * Returns the boolean value of whether the door is 'locked'.
	 * @return true if door is 'locked'.
	 */
	public boolean isLocked() {
		return isLocked;
	}

	/**
	 * Sets the value of the locked state of the Door.
	 * @param isLocked The boolean value representing the 'locked' state.
	 */
	public void setLocked(boolean isLocked) {
		this.isLocked = isLocked;
	}

}
