import javafx.scene.image.Image;

/**
 * The class for the greenKeyDoor object.
 * @author Elliot Davis
 * @version 1.0
 */
public class greenKeyDoor extends Door {

	/**
	 * The constructor for the greenKeyDoor object.
	 */
	public greenKeyDoor() {
		this.setPassable(true);
		this.setPassableEnemy(false);
		this.setLocked(true);
		this.setImage(new Image("/greenkeydoor.png"));
	}

	/**
	 * The method for handling player collision with self.
	 * @param player The player object.
	 */
	public void onTouch(Player player) {
		if (isLocked() && player.getGreenKeys() > 0) {
			player.setGreenKeys(player.getGreenKeys() - 1);
			setLocked(false);
			setPassableEnemy(true);
			this.setImage(new Image("/floor.png"));
		}
	}
}
