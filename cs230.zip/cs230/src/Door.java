public abstract class Door extends Tile{
	boolean isLocked;
}
