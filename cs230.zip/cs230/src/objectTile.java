public abstract class objectTile extends Tile{
	boolean pickedUp;
}
