import javafx.scene.image.Image;

/**
 * The class for the redKeyDoor object.
 * @author Unknown
 * @version 1.0
 */
public class redKeyDoor extends Door {
	/**
	 * The constructor for the redKeyDoor object.
	 */
	public redKeyDoor() {
		this.setPassable(true);
		this.setPassableEnemy(false);
		this.setLocked(true);
		this.setImage(new Image("/redkeydoor.png"));
	}

	/**
	 * The method for handling player collision with self.
	 * @param player The player object.
	 */
	public void onTouch(Player player) {
		if (isLocked() && player.getRedKeys() > 0) {
			player.setRedKeys(player.getRedKeys() - 1);
			setLocked(false);
			setPassableEnemy(true);
			this.setImage(new Image("/floor.png"));
		}
	}
}
