import javafx.scene.image.Image;

/**
 * The class for the yellowKeyDoor object.
 * @author Unknown
 * @version 1.0
 */
public class yellowKeyDoor extends Door {
	/**
	 * The constructor for the yellowKeyDoor object.
	 */
	public yellowKeyDoor() {
		setPassable(true);
		setPassableEnemy(false);
		setLocked(true);
		setImage(new Image("/yellowkeydoor.png"));
	}

	/**
	 * The method for handling player collision with self.
	 * @param player The player object.
	 */
	public void onTouch(Player player) {
		if (isLocked() && player.getYellowKeys() > 0) {
			player.setYellowKeys(player.getYellowKeys() - 1);
			setLocked(false);
			setPassableEnemy(true);
			setImage(new Image("/floor.png"));
		}
	}
}
