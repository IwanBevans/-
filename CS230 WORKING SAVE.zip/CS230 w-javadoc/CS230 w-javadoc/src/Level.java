

import java.util.ArrayList;
import java.util.Scanner;

/**
 * The level class constructs a 2d array of Tile
 * objects representing the level grid,
 * using a file as input.
 * @author Reece Veiga, Oliver Mance
 * @version 1.1
 */
public class Level {
	private int startingLocationX;
	private int startingLocationY;
	private int width;
	private int height;
	private Tile[][] tiles;
	private String fileName;
	private ArrayList<Enemy> allEnemies;

	/**
	 * Constructs a Level and populates grid with
	 * game object types based on data from a file.
	 * @param inputtedFile The input .txt file.
	 */
	public Level(String inputtedFile) {
		allEnemies = new ArrayList<Enemy>();
		fileName = inputtedFile;
		Scanner input = FileAccess.getFile(fileName);
			input.useDelimiter("\r\n|\n|,");
			if (!input.hasNextInt()) {
				fileName = input.next();
			}
			// creates 2D Array of Tile objects.
			width = input.nextInt();
			height = input.nextInt();
			tiles = new Tile[width][height];
			// Creates game objects in 2D Array of Tile objects.
			for (int y = 0; y < height; y ++) {
				String line = input.next();
				for (int x = 0; x < width; x ++) {
					switch (line.charAt(x)) {
					case '#':
						tiles[x][y] = new Wall();
						break;
					case ' ':
						tiles[x][y] = new Floor();
						break;
					case '@':
						tiles[x][y] = new Goal();
						break;
					case 'W':
						tiles[x][y] = new Water();
						break;
					case 'F':
						tiles[x][y] = new Fire();
						break;
					case 't':
						tiles[x][y] = new tokenTile();
						break;
					case 'f':
						tiles[x][y] = new fireBoots();
						break;
					case 'w':
						tiles[x][y] = new Flippers();
						break;
					case 'r':
						tiles[x][y] = new redKey();
						break;
					case 'b':
						tiles[x][y] = new blueKey();
						break;
					case 'g':
						tiles[x][y] = new greenKey();
						break;
					case 'y':
						tiles[x][y] = new yellowKey();
						break;
					case 'R':
						tiles[x][y] = new redKeyDoor();
						break;
					case 'B':
						tiles[x][y] = new blueKeyDoor();
						break;
					case 'G':
						tiles[x][y] = new greenKeyDoor();
						break;
					case 'Y':
						tiles[x][y] = new yellowKeyDoor();
						break;
					case 'I':
						tiles[x][y] = new Ice();
						break;
					}
				}
			} while (input.hasNext()) {
				int x = input.nextInt();
				int y = input.nextInt();
				String tileType = input.next();
				switch (tileType) {
				case "START":
					startingLocationX = x;
					startingLocationY = y;
					break;
				case "TOKENDOOR":
					tiles[x][y] = new tokenDoor(input.nextInt());
					break;
				case "TELEPORTER":
					tiles[x][y] = new Teleporter(input.nextInt(),input.nextInt());
					break;
				case "DUMBENEMY":
					allEnemies.add(new dumbEnemy(x,y));
					break;
				case "WALLENEMY":
					allEnemies.add(new wallEnemy(x,y));
					break;
				case "VERTICALENEMY":
					allEnemies.add(new lineEnemyVertical(x,y));
					break;
				case "HORIZONTALENEMY":
					allEnemies.add(new lineEnemyHorizontal(x,y));
					break;
				case "SMARTENEMY":
					allEnemies.add(new smartEnemy(x,y));
					break;
				case "SHARK":
					allEnemies.add(new Shark(x,y));
					break;
				case "HELPTILE":
					tiles[x][y] = new helpTile(input.next());
					break;
				case "CRACKEDFLOOR":
					tiles[x][y] = new crackedFloor(input.nextBoolean());
					break;
				}
			}
			input.close();
	}
	/**
	 * Get the X location of the player starting postion.
	 * @return The X coordinate of the player starting location.
	 */
	public int getStartingLocationX() {
		return startingLocationX;
	}
	/**
	 * Get the Y location of the player starting postion.
	 * @return The Y coordinate of the player starting location.
	 */
	public int getStartingLocationY() {
		return startingLocationY;
	}

	/**
	 * Get the width of the level grid.
	 * @return The width of level grid.
	 */
	public int getWidth() {
		return width;
	}
	/**
	 * Get the height of the level grid.
	 * @return The height of level grid.
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Get the 2d array of Tile objects.
	 * @return The 2D-Array of Tile objects.
	 */
	public Tile[][] getTiles() {
		return tiles;
	}

	/**
	 * Get string of the filename.
	 * @return The String of the filename.
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * Get the Arraylist of all enemies and their grid locations.
	 * @return The ArrayList of all enemies.
	 */
	public ArrayList<Enemy> getAllEnemies() {
		return allEnemies;
	}
}
