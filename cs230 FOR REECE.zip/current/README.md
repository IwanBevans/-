# macdonalds
TODO List:
PK - Create profile selection screen

Ideas for extra features:
- Having different types of tiles/enemies.
- Saving the inventory and where player is on the map.
- A tile that launches you forwards until you hit a wall.
- Bring up inventory mid game??

How to use GitHub: 
Firstly download git here: https://git-scm.com/downloads

Getting started and general commands:
1) Open command prompt
2) Change directory to where you want the repository in command prompt (using cd [directory] or cd ..)
3) Use the command below to copy the repository into your directory
            git clone https://github.com/IwanBevans/- 
4) Use 'git status' to track any changes you have made
5) Use 'git pull' to download any changes other people have uploaded
6) Use 'git' to see all the other commands

To upload a changed file
1) Use 'git add [file]' to upload the file to the repo, then check the changes using 'git status'
2) Commit the changes: git commit -m "message here"
3) Then push the changes (uploades them to GitHub): git push

To delete a file:
1) git rm file1.txt
2) git commit -m "remove file1.txt"
3) git push

Tutorial I watched: https://www.youtube.com/watch?v=0fKg7e37bQE 
Merge conflicts @ 15:30
