import javafx.scene.image.Image;

/**
 * The class for the greenKey object.
 * @author Unknown
 * @version 1.0
 */
public class greenKey extends objectTile {

	/**
	 * The constructor for the greenKey object.
	 */
	public greenKey() {
		this.setImage(new Image("/greenkey.png"));
		this.setPassable(true);
		this.setPassableEnemy(false);
		this.setPickedUp(false);
	}

	/**
	 * The method for handling player collision with self.
	 * @param player The player object.
	 */
	public void onTouch(Player player) {
		if (!this.isPickedUp()) {
			this.setPickedUp(true);
			this.setPassableEnemy(true);
			player.setGreenKeys(player.getGreenKeys() + 1);
			this.setImage(new Image("/floor.png"));
		}
	}
}
