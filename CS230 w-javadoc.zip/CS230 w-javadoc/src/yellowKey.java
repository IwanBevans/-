import javafx.scene.image.Image;
/**
 * The class for the yellowKey object.
 * @author Unknown
 * @version 1.0
 */
public class yellowKey extends objectTile {
	/**
	 * The constructor for the yellowKey object.
	 */
	public yellowKey() {
		setImage(new Image("/yellowkey.png"));
		setPassable(true);
		setPassableEnemy(false);
		setPickedUp(false);
	}

	/**
	 * The method for handling player collision with self.
	 * @param player The player object.
	 */
	public void onTouch(Player player) {
		if (!this.isPickedUp()) {
			this.setPickedUp(true);
			this.setPassableEnemy(true);
			player.setYellowKeys(player.getYellowKeys() + 1);
			this.setImage(new Image("/floor.png"));
		}
	}
}
