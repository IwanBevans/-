import javafx.scene.image.Image;

/**
 * The class for the fireBoots object.
 * @author Unknown
 * @version 1.0
 */
public class fireBoots extends objectTile {

	/**
	 * The constructor for the fireBoots object.
	 */
	public fireBoots() {
		setPickedUp(false);
		setPassable(true);
		setPassableEnemy(false);
		setImage(new Image("/fireboots.png"));
	}

	/**
	 * The method for handling player collision with self.
	 * @param player The player object.
	 */
	public void onTouch(Player player) {
		if (!this.isPickedUp()) {
			player.setFireBoots(true);
			this.setPickedUp(true);
			this.setPassableEnemy(true);
			this.setImage(new Image("/floor.png"));
		}
	}

}
