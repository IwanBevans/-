import javafx.scene.image.Image;

/**
 * The class for the redKey object.
 * @author Unknown
 * @version 1.0
 */
public class redKey extends objectTile {

	/**
	 * The constructor for the redKey object.
	 */
	public redKey() {
		this.setImage(new Image("/redkey.png"));
		this.setPassable(true);
		this.setPassableEnemy(false);
		this.setPickedUp(false);
	}

	/**
	 * The method for handling player collision with self.
	 * @param player The player object.
	 */
	public void onTouch(Player player) {
		if (!this.isPickedUp()) {
			this.setPickedUp(true);
			this.setPassableEnemy(true);
			player.setRedKeys(player.getRedKeys() + 1);
			this.setImage(new Image("/floor.png"));
		}
	}
}
