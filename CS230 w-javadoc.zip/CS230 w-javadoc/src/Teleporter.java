import javafx.scene.image.Image;

/**
 * The class for the Teleporter Tile object.
 * @author Unknown
 * @version 1.0
 */
public class Teleporter extends Tile{
	private int toLocationX;
	private int toLocationY;

	/**
	 * The constructor of the teleporter class, it creates pointers
	 * to the coordinates of its paired teleporter.
	 */
	public Teleporter(int toLocationX, int toLocationY) {
		this.toLocationX = toLocationX;
		this.toLocationY = toLocationY;
		setPassable(true);
		setPassableEnemy(false);
		setImage(new Image("/teleporter.png"));
	}

	/**
	 * The method for handling player collision with self.
	 * @param player The player object.
	 */
	public void onTouch(Player player) {
		player.setLocationX(getToLocationX());
		player.setLocationY(getToLocationY());
	}

	/**
	 * Gets the value for the X-coordinate of the to-location.
	 * @return X-coordinate of to-location.
	 */
	public int getToLocationX() {
		return toLocationX;
	}
	/**
	 * Gets the value for the Y-coordinate of the to-location.
	 * @return Y-coordinate of to-location.
	 */
	public int getToLocationY() {
		return toLocationY;
	}
}
